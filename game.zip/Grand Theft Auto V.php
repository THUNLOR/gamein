﻿<html>
  <meta name="viewport" content="width=device-width, initial-scale=1">
    <head>
        <title>
            Grand Theft Auto V
          </title>
        <style>
            html{
                background-color: black;
            }
            img{
    width: 28%;
    height: 30%;
    display: block;
    margin-left: auto;
    margin-right: auto;
      

  }
  .anna{
    margin-left: 38%;
    margin-right: auto;
    width: 30%;
    height: 30%;
    display: block;
  }

  .navbar {
      width: 100%;
      background-color:black;
      overflow: hidden;
      position: sticky;
    
    }
    
    /* Navigation links */
    .navbar a {
      float: left;
      padding: 12px;
      transition:0.3s;
      color:yellow;
      text-decoration: none;
      font-size: 17px;
      width: 22.40%; /* Four equal-width links. If you have two links, use 50%, and 33.33% for three links, etc.. */
      text-align: center; /* If you want the text to be centered */
      background-image:linear-gradient(90deg,black 0%,red 50%,black 50%,magenta 100%);
      background-size:200%;
      transition: background-position .3s,color .2s linear;
    transition-delay: 0.0s, 0.15s;
    font-weight:bolder;
    }
    .navbar a:hover{
      color:white;
      cursor:pointer;
      background-position: -100% 200%;
    }
    
    /* Add a background color on mouse-over */
    
    
    
    
    /* Add responsiveness - on screens less than 500px, make the navigation links appear on top of each other, instead of next to each other */
    @media screen and (max-width: 500px) {
      .navbar a {
        float: none;
        display: block;
        width: 100%;
        text-align: left; /* If you want the text to be left-aligned on small screens */
      }
    }
    

  .smg{
      width: 700px;
      height: 400px;
      left: 35px;
  }
  #game {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#game td, #game th {
  border: 1px solid #ddd;
  padding: 8px;
}

#game tr:nth-child(even){background-color: #f2f2f2;}

#game tr:hover {background-color: #ddd;}

#game th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: grey;
  color: white;
}

.kggc{
              width: 60%;
            }

            .con{
  width:100%;
  display:flex;
  flex-direction:row;
  
  }
  
  .con::-webkit-scrollbar {
    display: none;
  }
  
  /* Hide scrollbar for IE, Edge and Firefox */
  .con {
  -ms-overflow-style: none;  /* IE and Edge */
  scrollbar-width: none;  /* Firefox */
  }

  .yt {
  position: relative;
  max-width: 800px; /* Maximum width */
  margin: 0 auto; /* Center it */
}

  .ytlink{
    position: absolute; /* Position the background text */
  bottom: 0; /* At the bottom. Use top:0 to append it to the top */
  background: rgb(0, 0, 0); /* Fallback color */
  background: rgba(0, 0, 0, 0.5); /* Black background with 0.5 opacity */
  color: #f1f1f1; /* Grey text */
  width: 100%; /* Full width */
  padding: 20px;
  text-align: center ; /* Some padding */
}

.wall{
    height: 300px;
    width: 500px;
}

.column {
  float: left;
  width: 33.33%;
  padding: 10px;
}
</style>
      <img style="float: left;" src="https://cdn.discordapp.com/attachments/759665069746552883/777780569106153482/SquarePic_20201116_11520343.jpg" height="10" width="10">
      <img class="anna" src="https://cdn.discordapp.com/attachments/759665069746552883/777777786811056177/SquarePic_20201116_11355640.jpg" height="10" width="10">
    </head>
    <body>
      <div class="navbar">
        <a href="My_Page.html">Home</a>
        <a class="active" href="Trending.html">Trending</a>
        <a href="News and Updates.html">News and Updates</a>
        <a href="#">Login</a>
      </div>
      <br>
      <br>
        <h1 style="color: yellow;font-family: 'Times New Roman', Times, serif;font-weight: bold;font-size: 400%;text-align: center;">Grand Theft Auto V</h1>
        <br>
        <br>
        <br>
        <br>
        <img class="smg" src="https://cdn.wallpapersafari.com/78/46/gNHXMs.jpg">
        <br>
        <br>
        <br>
        <br>
        <h1 style="color: yellow;font-family: 'Times New Roman', Times, serif;font-weight: bold;font-size: 200%;text-align: left;">Description :</h1>
        <br>
        <br>
        <p style="color: white;font-family: 'Times New Roman', Times, serif;font-size: 150%;font-weight: bold;text-align: center;">Grand Theft Auto V is a 2013 action-adventure game developed by Rockstar North and published by Rockstar Games. It is the first main entry in the Grand Theft Auto series since 2008's Grand Theft Auto IV. Set within the fictional state of San Andreas, based on Southern California, the single-player story follows three protagonists—retired bank robber Michael De Santa, street gangster Franklin Clinton, and drug dealer and arms smuggler Trevor Philips—and their efforts to commit heists while under pressure from a corrupt government agency and powerful crime figures. The open world design lets players freely roam San Andreas' open countryside and the fictional city of Los Santos, based on Los Angeles.</p>
        <p style="color: white;font-family: 'Times New Roman', Times, serif;font-size: 150%;font-weight: bold;text-align: center;">The game is played from either a third-person or first-person perspective, and its world is navigated on foot or by vehicle. Players control the three lead protagonists throughout single-player and switch among them, both during and outside missions. The story is centred on the heist sequences, and many missions involve shooting and driving gameplay. A "wanted" system governs the aggression of law enforcement response to players who commit crimes. Grand Theft Auto Online, the game's online multiplayer mode, lets up to 30 players engage in a variety of different cooperative and competitive game modes.</p>
        <br>
        <br>
        <h1 style="color: yellow;font-family: 'Times New Roman', Times, serif;font-weight: bold;font-size: 200%;text-align: left;">Story Line :</h1>
        <br>
        <br>
        <p style="color: white;font-family: 'Times New Roman', Times, serif;font-size: 150%;font-weight: bold;text-align: center;">In 2004,[i] Michael Townley, Trevor Philips, and Brad Snider partake in a botched robbery in Ludendorff, North Yankton, resulting in all three being presumed dead. Nine years later, Michael is living under witness protection with his family in the city of Los Santos, under the alias Michael De Santa. Across town, gangbanger Franklin Clinton is working for a corrupt Armenian car salesman and meets Michael while attempting to fraudulently repossess his son's car; the two later become friends. When Michael finds his wife Amanda sleeping with her tennis coach, he and Franklin chase the coach to a mansion, which Michael partially destroys in anger. The owner of the mansion turns out to be the girlfriend of Martin Madrazo, a Mexican drug lord who demands compensation to avoid further violence. Michael returns to a life of crime to obtain the money, enlisting Franklin as an accomplice. With the help of Michael's old friend Lester Crest, a disabled hacker, they perform a jewellery store heist to pay off the debt. Meanwhile, Trevor, who now lives in a trailer park on the outskirts of Los Santos, hears of the heist and realises that it was Michael's work; Trevor had believed that Michael was killed in their botched robbery nine years ago. Trevor tracks Michael down and reunites with him, forcing a reluctant Michael to accept him back into his life.

            As time goes on, the personal lives of the protagonists begin to spiral out of control. Michael's increasingly disreputable behaviour prompts his family to leave him. When he becomes a movie producer at the film studio Richards Majestic, Michael comes into conflict with Devin Weston, a self-made billionaire venture capitalist and corporate raider, who vows revenge after his attempts to shut down the studio are thwarted by Michael. Franklin, meanwhile, rescues his friend Lamar Davis from rival gangster and former friend Harold "Stretch" Joseph, who repeatedly attempts to kill Lamar to prove himself to his new brethren. At the same time, Trevor's reckless efforts to consolidate his control over various black markets in Blaine County see him waging war against The Lost outlaw motorcycle club, several Latin American street gangs, rival meth dealers, private security firm Merryweather Security, and Triad kingpin Wei Cheng.
            
            Federal Investigation Bureau (FIB) agents Dave Norton and Steve Haines contact Michael and demand that he, Franklin, and Trevor perform a series of operations to undermine a rival agency, the International Affairs Agency (IAA).[j] Under Steve's direction and with Lester's help, they attack an armoured convoy carrying funds intended for the IAA, and steal an experimental chemical weapon from an IAA-controlled lab. As Steve comes under increasing scrutiny, he forces Michael and Franklin to erase any evidence being used against him from the FIB servers. Michael takes the opportunity to wipe the data on his activities, destroying Steve's leverage over him.
            
            Eventually, Michael, Trevor, Franklin, and Lester start planning their most significant heist ever: raiding the Union Depository's gold bullion reserve. By this time, Michael reconciles with his family. However, Trevor discovers that Brad was not imprisoned as led to believe, but killed during the Ludendorff heist and buried in the grave marked for Michael. Trevor's feelings of betrayal cause friction within the group and threaten to undermine their Union Depository plans. Steve betrays Michael and Dave, and they become caught in a Mexican standoff between the FIB, IAA, and Merryweather. Trevor, feeling that he is the only one who has the right to kill Michael, comes to their aid. Despite not forgiving Michael, Trevor agrees to perform the Union Depository heist and part ways with him afterwards.
            
            The heist is successful, but Franklin is then approached separately by Steve and Dave, who contend that Trevor is a liability, and Devin, who wants retribution for Michael's betrayal. Franklin has three choices: kill Trevor, kill Michael, or attempt to save both in a suicide mission. Should Franklin choose to kill either Michael or Trevor, he ceases contact with the man he spares and returns to his old life.[31][32] Otherwise, the trio withstands an onslaught from the FIB and Merryweather before going on to kill Cheng, Stretch, Steve, and Devin. Michael and Trevor reconcile, and the three protagonists cease working together but remain friends.[33]</p>
            <br>
            <br>
            <br>
            <br>

<?php
  
  $conn=mysqli_connect("localhost","root","","sss");
  if(mysqli_connect_errno()){
   echo "FAILED TO CONNECT";
}
  
$result = mysqli_query($conn,"SELECT * FROM gamedata WHERE NAME ='GRAND THEFT AUTO 5'");


           echo "<table border=1 id=game>
                <tr>
                  <th>Name</th>
                  <th>Developer(s)</th>
                  <th>Publisher(s)</th>
                  <th>Series</th>
                  <th>Engine</th>
                  <th>Platform(s)</th>
                  <th>Release</th>
                  <th>Genre(s)</th>
                  <th>Mode(s)</th>
                  </tr>";


$row = mysqli_fetch_array($result);

echo "<tr>";
echo "<td>" . $row['Name'] . "</td>";
echo "<td>" . $row['Developer(s)'] . "</td>";
echo "<td>" . $row['Publisher(s)'] . "</td>";
echo "<td>" . $row['Series'] . "</td>";
echo "<td>" . $row['Engine'] . "</td>";
echo "<td>" . $row['Platform(s)'] . "</td>";
echo "<td>" . $row['Release'] . "</td>";
echo "<td>" . $row['Genre(s)'] . "</td>";
echo "<td>" . $row['Mode(s)'] . "</td>";

echo "</tr>";


          echo "</table>"

?>

            <br>
            <br>
            <h1 style="color: yellow;font-family: 'Times New Roman', Times, serif;font-size: 400%;font-weight: bold;text-align: center;">Specifications for PC</h1>
            <br>
            <br>
            <table id="game">
                <tr>
                  <th>Operating System</th>
                  <th>CPU</th>
                  <th>GPU</th>
                  <th>Memory</th>
                  <th>Sound Card</th>
                  <th>HDD/SSD Space</th>
                </tr>
                <tr>
                    <td>Windows 8.1 64 Bit, Windows 8 64 Bit, Windows 7 64 Bit Service Pack 1, Windows Vista 64 Bit Service Pack 2* (*Nvidia video card recommended if running Vista OS)</td>
                    <td>Intel Core 2 Quad CPU Q6600 @ 2.40GHz (4 CPUs) / AMD Phenom 9850 Quad-Core Processor (4 CPUs) @ 2.5GHz</td>
                    <td>4GB</td>
                    <td>Nvidia 9800 GT 1GB / AMD HD 4870 1GB (DX 10, 10.1, 11)</td>
                    <td>100 Percent DirectX 10 compatible</td>
                    <td>65GB</td>
                  </tr>
            </table>
            <br>
            <br>
            <h1 style="color: yellow;font-family: 'Times New Roman', Times, serif;font-size: 400%;font-weight: bold;text-align: center;">Official Trailer</h1>
            <br>
            <br>
            <iframe class="kggc" style="margin-left: 20%;" width="1080" height="600" src="https://www.youtube.com/embed/QkkoHAzjnUs" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            <br>
            <br>
            <h1 style="color: yellow;font-family: 'Times New Roman', Times, serif;font-size: 400%;font-weight: bold;text-align: center;">Some famous channels for this title</h1>
            <br>
            <br>
            <div class="con">

                <div class="column">
                <a href="https://www.youtube.com/user/GTASeriesVideos">
                <div class="yt">
                    <img class="wall" src="https://i.ytimg.com/vi/MoVMquWv5FE/maxresdefault.jpg" alt="GTA Series Videos">
                    <div class="ytlink">
                      <h1>GTA Series Videos</h1>
                    </div>
                  </div>
                </div>
                </a>
                <div class="column">
                <a href="https://www.youtube.com/user/GhillieMaster16">
                    <div class="yt">
                        <img class="wall" src="https://yt3.ggpht.com/ytc/AAUvwngmF-paI3haT7fC4KHZSgul3-GXEHwG3E_-f91KOg=s900-c-k-c0x00ffffff-no-rj" alt="GTA Gentlemen">
                        <div class="ytlink">
                          <h1>GTA Gentlemen</h1>
                        </div>
                      </div>
                    </a>
                </div>
                <div class="column">
                    <a href="https://www.youtube.com/channel/UC72PuhDwKtZ5MikpGNhPAtA">
                        <div class="yt">
                            <img class="wall" src="https://yt3.ggpht.com/ytc/AAUvwnhfcU1MlI0911FA1QEAauhR8v0VfV2nK3tFCNq-Uw=s900-c-k-c0x00ffffff-no-rj" alt="TGG">
                            <div class="ytlink">
                              <h1>TGG</h1>
                            </div>
                          </div>
                        </a>
                </div>

            </div>



    </body>
    </html>